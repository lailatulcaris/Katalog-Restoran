import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';
import data from '../public/data/DATA.json';

const restaurantsList = document.querySelector('.restaurants__list');

data.restaurants.forEach(restaurant => {

    const restaurantCard = document.createElement('div');
    restaurantCard.classList.add('restaurant-card');

    restaurantCard.innerHTML = `
        <img tabindex="0" src="${restaurant.pictureId}" alt="${restaurant.name}" class="restaurant-image">
        <div class="restaurant-details">
          <h2 tabindex="0" class="restaurant-name">${restaurant.name}</h2>
          <p tabindex="0" class="restaurant-city">${restaurant.city}</p>
          <p tabindex="0" class="restaurant-rating">Rating: ${restaurant.rating}</p>
          <p tabindex="0" class="restaurant-description">${restaurant.description}</p>
        </div>
    `;

    restaurantsList.appendChild(restaurantCard);
});

const menu_hamburger = document.querySelector('#menu_hamburger');
const hero = document.querySelector('.hero');
const main = document.querySelector('main');
const drawer = document.querySelector('#navigation_drawer');

menu_hamburger.addEventListener('click', function (event) {
    navigation_drawer.classList.toggle('open');
    event.stopPropagation();
});

hero.addEventListener('click', function () {
    navigation_drawer.classList.remove('open');
});

main.addEventListener('click', function () {
    navigation_drawer.classList.remove('open');
});
